//
//  PlanetViewController.swift
//  exampleProject
//
//  Created by Daesy Vences on 11/1/22.
//

import UIKit

class PlanetViewController: UIViewController {
    
    //image view
    @IBOutlet weak var planetImage: UIImageView!
    
    // switch
    @IBOutlet weak var selector: UISwitch!
    
    
    @IBOutlet weak var earthLabel: UILabel!
    
    
    @IBOutlet weak var marsLabel: UILabel!
    
    
    // put code in here to hide the imageview at the inital load of the app.
    override func viewDidLoad() {
        super.viewDidLoad()
        planetImage.isHidden = true
       
    }
    
// here is the code that changes the imageview back and forth depending on if the switch is on or not.
    
    @IBAction func favoritePlanet(_ sender: UISwitch) {
        if selector.isOn {
            planetImage.isHidden = false
            planetImage.image = UIImage(named: "mars")
            earthLabel.isHidden = true
            marsLabel.isHidden = false
        } else {
            planetImage.isHidden = false
            planetImage.image = UIImage(named: "earth")
            earthLabel.isHidden = false
            marsLabel.isHidden = true
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
